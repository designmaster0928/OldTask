// main.c

// DSPIC33FJ16MC102 Configuration Bit Settings

// 'C' source line config statements

// CONFIG2
#pragma config POSCMOD = NONE           // Primary Oscillator Select (Primary oscillator disabled)
#pragma config ALTI2C = OFF             // Alternate I2C pins (I2C mapped to SDA1/SCL1)
#pragma config LPOL = ON                // Motor Control PWM Low Side Polarity bit (PWM module low side output pins have active-high output polarity)
#pragma config IOL1WAY = ON             // IOLOCK Protection (Allow Only One Re-configuration)
#pragma config OSCIOFNC = OFF           // Primary Oscillator Output Function (OSC2 pin has clock out function)
#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor (Clock switching and Fail-Safe Clock Monitor are disabled)
#pragma config FNOSC = FRCDIVN          // Oscillator Mode (Internal Fast RC (FRC) with divide by N)
#pragma config WDTWIN = WDTWIN25        // Watchdog Window Select (Watchdog Window is 25% of WDT period)
#pragma config PWMPIN = ON              // Motor Control PWM Module Pin Mode bit (PWM module pins controlled by PORT register at device Reset)
#pragma config PWMLOCK = ON             // PWM Lock Enable (Certain PWM registers may only be written after key sequence)
#pragma config IESO = ON                // Internal External Switch Over Mode (Start-up device with FRC, then automatically switch to user-selected oscillator source when ready)

// CONFIG1
#pragma config WDTPOST = PS32768        // Watchdog Timer Postscaler (1:32,768)
#pragma config WDTPRE = PR128           // WDT Prescaler (Prescaler ratio of 1:128)
#pragma config PLLKEN = ON              // PLL Lock Enable (Clock switch to PLL source will wait until the PLL lock signal is valid.)
#pragma config WINDIS = OFF             // Watchdog Timer Window (Watchdog Timer in Non-Window mode)
#pragma config FWDTEN = OFF              // Watchdog Timer Enable (Watchdog timer always enabled)
#pragma config ICS = PGD1               // Comm Channel Select (Communicate on PGEC1/PGED1)
#pragma config HPOL = ON                // Motor Control PWM High Side Polarity bit (PWM module high side output pins have active-high output polarity)
#pragma config GWRP = OFF               // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF                // General Segment Code Protection (General Segment Code protect is disabled)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#include <xc.h>

#define FCY 10000000UL
#include <libpic30.h>
#include <p33FJ16MC102.h>

/******************************************************************************/
/***** GLOBAL VARIABLES *******************************************************/
/******************************************************************************/

short phi = 0; // Phase
char quad = 1; // Quadrant

// Sine wave converted in a duty cycle in 101 points
// for the 1st quadrant only: [0�-90�] (limits included)
const unsigned short sin100_0_90[101] = {
    12000, 12188, 12377, 12565, 12753, 12942, 13129, 13317, 13504, 13691, 
    13877, 14063, 14249, 14433, 14618, 14801, 14984, 15166, 15348, 15528, 
    15708, 15887, 16065, 16242, 16417, 16592, 16766, 16938, 17109, 17279, 
    17448, 17615, 17781, 17946, 18108, 18270, 18430, 18588, 18745, 18900, 
    19053, 19205, 19355, 19503, 19649, 19793, 19936, 20076, 20215, 20351, 
    20485, 20618, 20748, 20876, 21001, 21125, 21246, 21365, 21482, 21596, 
    21708, 21818, 21925, 22030, 22132, 22232, 22329, 22424, 22516, 22605, 
    22692, 22776, 22858, 22937, 23013, 23087, 23157, 23225, 23291, 23353, 
    23413, 23470, 23524, 23575, 23623, 23668, 23711, 23751, 23787, 23821, 
    23852, 23880, 23905, 23928, 23947, 23963, 23976, 23987, 23994, 23999, 
    24000,
};

int main(void) {
    
/******************************************************************************/
/***** INITIALIZATION: OSCILLATOR *********************************************/
/******************************************************************************/
    
    // EXTERNAL CRYSTAL FREQUENCY: 10 MHz
    // FCY = 60 MHz (30 MIPS)
    // NOTE: CPU can work faster (up to 70 MIPS), but PWM then must use (poor) FRC oscillator.
    
    // FPLLI=FIN/N1
    // N1=PLLPRE+2, N1 in [2,33]
    short N1 = 2;
//    CLKDIVbits.PLLPRE = N1-2; // N1=PLLPRE+2=2
    
    // FVCO=FPLLI*M
    // M=PLLDIV+2, M in [2,513]
    short M = 24;
//    PLLFBD = M-2;
    
    // FPLLO=FVCO/N2 (FPLLO=FOSC, FCY=FOSC/2)
    // N2=2*(PLLPOST+1), N2 is {2,4,8}
    short N2 = 2; // 2, 4 or 8
//    CLKDIVbits.PLLPOST = N2/2-1;
    
    /*
    ** Initiate clock switch
    ** 1. Wait for clock switch to occur
    ** 2. Wait for PLL to lock
    */
    
    // Primary Oscillator with PLL (XTPLL, HSPLL, ECPLL)
    __builtin_write_OSCCONH(0x03); // 0b011 -> NOSC<2:0> (OSCCON<10:8>)
    
    // Request oscillator switch to selection specified by the NOSC<2:0> bits
    __builtin_write_OSCCONL(OSCCON | 0x01); // 0b1 -> OSWEN<0> (OSCCON<0>)
    
    // Wait for Clock switch to occur
    // Current Oscillator Selection bits (read-only): COSC<2:0> (OSCCON<15:13>)
//    while (OSCCONbits.COSC!=0b011);
    
    // Wait for PLL to lock
    // PLL Lock Status bit (read-only): LOCK<0> (OSCCON<5>)
//    while (OSCCONbits.LOCK!=1);
    
    /*
    ** Configure auxiliary oscillator
    ** 112-120 MHz for proper PWM and ADC operation
    */
    
    // Configure source to fast RC with APLL
//    ACLKCONbits.SELACLK = 0; // Use primary PLL as a source (FVCO = 120 MHz)
//    ACLKCONbits.APSTSCLR = 0b111; // Divide-by-1 for PWM
    
/******************************************************************************/
/***** INITIALIZATION: PORTS **************************************************/
/******************************************************************************/
    
    // Set all ports to low
    LATA = 0x00;
    LATB = 0x00;
//    LATC = 0x00;
//    LATD = 0x00;
    
    // Set all ports to digital
    AD1PCFGL = 0xffff;  // digital
//    ANSELA = 0x00;
//    ANSELB = 0x00;
//    ANSELC = 0x00;
//    ANSELD = 0x00;
    
    // Set all ports to digital output
    TRISA = 0x00;
    TRISB = 0x00;
//    TRISC = 0x00;
//    TRISD = 0x00;
    
/******************************************************************************/
/***** INITIALIZATION: PWM ****************************************************/
/******************************************************************************/
    
    // ACRONYMS:
    // PWM Pulse-Width Modulation
    // ITB Independent Time Base
    // CAM Center-Aligned Mode
    // CMM Complementary mode
    
    // PWM time base control register
    PTCONbits.PTEN = 0; // Disable high-speed PWM module
//    PTCONbits.EIPU = 0; // Active period register updates occur on PWM cycle boundaries
    
    // PWM clock divider select register
//    PTCON2bits.PCLKDIV = 0b000; // Divide-by-1, maximum PWM timing resolution

// Enable PWM outputs    
    PWM1CON1bits.PEN1H = 1;
    PWM1CON1bits.PEN1L = 1;
    PWM1CON1bits.PEN2H = 1;
    PWM1CON1bits.PEN2L = 1;
    PWM1CON1bits.PEN3H = 1;
    PWM1CON1bits.PEN3L = 1;
// Complememntary mode 0, independent 1
    PWM1CON1bits.PMOD1 = 0;
    PWM1CON1bits.PMOD2 = 0;
    PWM1CON1bits.PMOD3 = 0;
    
    // Configure PWM2 generator
    PWM1CON2bits.OSYNC = 0;
    PWM1CON2bits.SEVOPS = 0b0011;   // 1:4 Postscale
    PWM1CON2bits.UDIS = 0; // Updates enabled
    PWM1CON2bits.IUE = 0; // Updates to the active PDCx/SDCx registers are synchronized to the local PWM time base
//    PWMCON2bits.CAM = 1; // Center-aligned mode (must use ITB)
//    PWMCON2bits.ITB = 1; // Enable independent time base (must use for CAM)
//    PWMCON2bits.MDCS = 0; // PDCx/SDCx registers provide duty cycle
//    PWMCON2bits.DTC = 0b00; // Positive dead-time is actively applied for all output modes
//    PWMCON2bits.TRGIEN = 1; // A trigger event generates an IRQ
    
    // In a case of the center-aligned mode (CAM), PHASEx/SPHASEx registers provide the time base period
    // {PTPER,STPER,PHASEx,SPHASEx} = [(ACLK*8*PWM_PERIOD)/(PCLKDIV)]-8
    // ACLK = 120 MHz (see auxiliary oscillator in the oscillator initialization routine)
//    PHASE2 = 23992; // 40 kHz, 25 us
    
    // PWMx generator duty cycle register
    P1DC1 = 2000;
    P1DC2 = 2000;
    
    P1TPER = 4000;
//    P2TPER = 6000;
//    P1DC3 = 2000;        '
//    PDC2 = 2000; // 8 -> 0%
    
    // PWMx alternate dead-time register
    // In the case of the center-aligned mode configured in the complementary mode,
    // only ALTDTRx provides dead-time period, whereas DTRx is not used
    // {DTRx,ALTDTRx} = (ACLK*8*DEAD_TIME)/(PCLKDIV)
//    ALTDTR2 = 144; // 150 ns
    
    // PWMx I/O control register
//    IOCON2bits.PENH = 1; // PWMx module controls the PWMxH pin
//    IOCON2bits.PENL = 1; // PWMx module controls the PWMxL pin
//    IOCON2bits.POLH = 0; // PWMxH pin is active-high
//    IOCON2bits.POLL = 0; // PWMxL pin is active-high
//    IOCON2bits.PMOD = 0b00; // PWMx I/O pin pair is in the Complementary PWM output mode
//    IOCON2bits.OVRENH = 0; // PWMx generator provides data for the PWMxH pin
//    IOCON2bits.OVRENL = 0; // PWMx generator provides data for the PWMxL pin
//    IOCON2bits.SWAP = 0; // PWMxH and PWMxL pins are mapped to their respective pins
    
    // Enable PWM interrupt
//    IFS5bits.PWM2IF = 0;
//    IEC5bits.PWM2IE = 1;
//    IPC23bits.PWM2IP = 0b111;
    
    IEC3bits.PWM1IE = 1;    // Enable PWM interrupt
    // Enable high-speed PWM
    PTCONbits.PTEN = 1;
    
/******************************************************************************/
/***** INFINITE LOOP **********************************************************/
/******************************************************************************/
    
    while(1) {
        LATAbits.LATA0 ^= 1;
//        __delay_ms(1);
//        PORTAbits.RA0 ^= 1;
//        __delay_ms(1);
//        PORTA = 1;
        __delay_ms(1);
    }
}

/******************************************************************************/
/***** INTERRUPT SERVICE ROUTINE: PWM2 ****************************************/
/******************************************************************************/

// Sinewave is generated in this function

void __attribute__((interrupt, no_auto_psv)) _DefaultInterrupt(void) {
    IFS3bits.PWM1IF = 0;    
}
//void __attribute__((__interrupt__, auto_psv)) _PWM1Interrupt(void) {
void __attribute__((interrupt, no_auto_psv)) _PWM1Interrupt(void) {
    // Clear PWM2 interrupt flag
//    IFS5bits.PWM2IF = 0;
    IFS3bits.PWM1IF = 0;
    LATAbits.LATA0 ^= 1;
    if (quad==1) {
        PDC2 = sin100_0_90[phi];
        if (phi==100) {
            quad = 2;
            phi--;
        } else {
            phi++;
        }
    } else if (quad==2) {
        PDC2 = sin100_0_90[phi];
        if (phi==0) {
            quad = 3;
            phi++;
        } else {
            phi--;
        }
    } else if (quad==3) {
        PDC2 = 24000-sin100_0_90[phi];
        if (phi==100) {
            quad = 4;
            phi--;
        } else {
            phi++;
        }
    } else if (quad==4) {
        PDC2 = 24000-sin100_0_90[phi];
        if (phi==0) {
            quad = 1;
            phi++;
        } else {
            phi--;
        }
    } else {
        // error: do nothing
    }
    
    return;
}